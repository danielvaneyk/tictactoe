let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
let gameActive = true;

const winningCombinations = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6]             // diagonals
];

function handleClick(index) {
  if (board[index] === '' && gameActive) {
    board[index] = currentPlayer;
    renderBoard();
    handleResultValidation();
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  }
}

function renderBoard() {
  const boardElement = document.getElementById('board');
  boardElement.innerHTML = '';
  board.forEach((cell, index) => {
    const cellElement = document.createElement('div');
    cellElement.innerText = cell;
    cellElement.classList.add('cell');
    cellElement.onclick = () => handleClick(index);
    boardElement.appendChild(cellElement);
  });
}

function handleResultValidation() {
  let roundWon = false;
  let winningPlayer = null;

  for (let i = 0; i < winningCombinations.length; i++) {
    const [a, b, c] = winningCombinations[i];
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      roundWon = true;
      winningPlayer = board[a];
      break;
    }
  }

  if (roundWon) {
    gameActive = false;
    showWinMessage(winningPlayer);
    return;
  }

  if (!board.includes('')) {
    gameActive = false;
    setTimeout(() => {
      alert(`It's a draw!`);
    }, 100);
    return;
  }
}

function showWinMessage(player) {
  const winMessage = document.createElement('div');
  winMessage.innerText = `${player} Wins!`;
  winMessage.style.color = 'orange';
  winMessage.style.fontWeight = 'bold';
  winMessage.style.fontSize = '12px';
  winMessage.style.textOutline = '2px solid black';
  winMessage.style.textAlign = 'center';
  winMessage.style.padding = '20px';
  winMessage.style.backgroundColor = 'white';
  winMessage.style.position = 'absolute';
  winMessage.style.top = '50%';
  winMessage.style.left = '50%';
  winMessage.style.transform = 'translate(-50%, -50%)';
  winMessage.style.zIndex = '999';
  winMessage.style.borderRadius = '10px';
  winMessage.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.3)';
  
  const okButton = document.createElement('button');
  okButton.innerText = 'Ok';
  okButton.style.marginTop = '10px';
  okButton.onclick = function() {
    document.body.removeChild(winMessage);
    resetGame();
  };

  winMessage.appendChild(okButton);
  document.body.appendChild(winMessage);
}

function resetGame() {
  currentPlayer = 'X';
  board = ['', '', '', '', '', '', '', '', ''];
  gameActive = true;
  renderBoard();
}

renderBoard();